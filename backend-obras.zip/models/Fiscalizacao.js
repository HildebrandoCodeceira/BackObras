
// Modelo da fiscalização (igual ao exemplo da resposta anterior)
