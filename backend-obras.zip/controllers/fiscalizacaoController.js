
// Código do controlador de fiscalizações (igual ao exemplo da resposta anterior)
