
// Serviço de email (igual ao exemplo da resposta anterior)
