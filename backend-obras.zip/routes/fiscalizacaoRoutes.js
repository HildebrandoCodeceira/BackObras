
// Rotas de fiscalizações (igual ao exemplo da resposta anterior)
