# Backend Cadastro de Obras

## Tecnologias
Node.js, MongoDB, Mongoose, Express.js, Nodemailer (simulado)

## Como rodar
npm install
npm start

## Endpoints principais
- /obras
- /fiscalizacoes
- /obras/:id/fiscalizacoes
- /obras/:id/enviar-email
